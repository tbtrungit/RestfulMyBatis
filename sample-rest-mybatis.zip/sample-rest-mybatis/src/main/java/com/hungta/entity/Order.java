package com.hungta.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author HUNGTA on 01/08/18 - 10:26 PM
 * @project restfulmybatis
 */

@Data
@AllArgsConstructor
public class Order implements Serializable {

    private String orderId;
    private String orderName;
    private String productName;
    private int quantity;
    private int price;
    private String type;
    private int total;
    private int customerId;
    private String customerName;
    private String orderDate;
    private String status;

  
}
