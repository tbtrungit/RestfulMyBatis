package com.hungta.entity;

import lombok.Data;

@Data
public class FileInfo {
	private String fileName;
	private long fileSize;

	

}
