package com.hungta.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * @author HUNGTA on 01/11/18 - 12:41 AM
 * @project restful-mybatis
 */
@Data
public class User implements UserDetails, Serializable  {

    private Long id;

    private String username;

    @JsonIgnore
    private String password;

    private String firstname;

    private String lastname;

    private List<Authority> authorities;

     public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.authorities;
    }

    public String getPassword() {
        return this.password;
    }

    public String getUsername() {
        return username;
    }

    @JsonIgnore
    public boolean isAccountNonExpired() {
        return true;
    }

    @JsonIgnore
    public boolean isAccountNonLocked() {
        return true;
    }

    @JsonIgnore
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @JsonIgnore
    public boolean isEnabled() {
        return true;
    }
}
