package com.hungta.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

import org.springframework.security.core.GrantedAuthority;

/**
 * @author HUNGTA on 01/11/18 - 12:41 AM
 * @project restful-mybatis
 */
@Data
public class Authority implements GrantedAuthority {

    private Long id;

    String name;

    public String getAuthority() {
        return name;
    }
}
