package com.hungta.controller;

import java.io.File;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.hungta.entity.FileInfo;

/** 
 * 
 * @author TrungTB1
 * @since 26/01/2018
 * @version 1.
 * @category UploadFile
 * 
 */

@RestController
public class FileUploadController {
	//Using ServletContext
	@Autowired
	ServletContext context;
	
	//using mutipart upload file
	@RequestMapping(value = "/fileupload", headers = ("content-type=multipart/*"), method = RequestMethod.POST)
	public ResponseEntity<FileInfo> upload(@RequestParam("file") MultipartFile inputFile) {
		FileInfo fileInfo = new FileInfo();
		HttpHeaders headers = new HttpHeaders();
		//check if file not empty then begin upload
		if (!inputFile.isEmpty()) {
			try {
				//Get name file upload
				String originalFilename = inputFile.getOriginalFilename();
				//get full path
				File destinationFile = new File(
						context.getRealPath("/WEB-INF/uploaded") + File.separator + originalFilename);
				//Beging upload file
				inputFile.transferTo(destinationFile);
				//set file name has upload in server
				fileInfo.setFileName(destinationFile.getPath());
				//set file size has upload in server
				fileInfo.setFileSize(inputFile.getSize());
				headers.add("File Uploaded Successfully - ", originalFilename);
				return new ResponseEntity<FileInfo>(fileInfo, headers, HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity<FileInfo>(HttpStatus.BAD_REQUEST);
			}
		} else {
			return new ResponseEntity<FileInfo>(HttpStatus.BAD_REQUEST);
		}
	}
}