package com.hungta.dao;

import com.github.pagehelper.Page;
import com.hungta.entity.Order;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

/**
 * @author HUNGTA on 01/08/18 - 9:49 PM
 * @project restfulmybatis
 */
@Repository
public interface OrderDao {

    int createOrder(Order order);

    int updateOrder(Order order);

    int deleteOrder(String orderId);
    List<Order> findAll2(HashMap<String, Integer> offsetLimit);


    Order findByOrderName(String orderName);

    Order findByOrderId(String orderId);

    //  @Select("SELECT orderId, productName, quantity, price, type, customerId, customerName, orderDate, total, orderName, status FROM orders")
    List<Order> findAll();

    Page<Order> findAllPaging(@Param("pageNum") Integer pageNum, @Param("pageSize") Integer pageSize);
}
