package com.hungta.model;

import lombok.Data;

@Data
public class UserTokenState {
    private String access_token;
    private Long expires_in;
  
}
