package com.hungta.security.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author HUNGTA on 01/23/18 - 1:38 AM
 * @project restful-mybatis
 */
@Data
@AllArgsConstructor
public class AuthenticationResponse {
    private String access_token;
}
